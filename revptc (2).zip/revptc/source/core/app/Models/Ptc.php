<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ptc extends Model
{
    protected $guarded = ['id'];
}
